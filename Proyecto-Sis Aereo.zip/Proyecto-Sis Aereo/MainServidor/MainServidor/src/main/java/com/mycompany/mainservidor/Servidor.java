/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.mainservidor;
import java.io.*;
import java.net.*;
import java.util.HashMap;
import java.util.Map;
/**
 *
 * @author camim
 */
public class Servidor {
    private static final int PUERTO = 5000;
    private static final Map<String, String> usuarios = new HashMap<>();
    static {
        usuarios.put("Piloto1", "Piloto123");
        usuarios.put("Piloto2", "Piloto123");
    }

    public static void iniciarServidor() {
        try {
            ServerSocket serverSocket = new ServerSocket(PUERTO);
            System.out.println("Servidor iniciado. Esperando conexiones...");

            while (true) {
                Socket socketCliente = serverSocket.accept();
                System.out.println("Cliente conectado: " + socketCliente.getInetAddress().getHostAddress());

                new HiloCliente(socketCliente).start();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private static class HiloCliente extends Thread {
        private Socket socketCliente;
        private DataInputStream entrada;
        private DataOutputStream salida;

        public HiloCliente(Socket socketCliente) {
            this.socketCliente = socketCliente;
        }

        public void run() {
            try {
                entrada = new DataInputStream(socketCliente.getInputStream());
                salida = new DataOutputStream(socketCliente.getOutputStream());

                String usuario = entrada.readUTF();
                String contrasena = entrada.readUTF();

                if (autenticarUsuario(usuario, contrasena)) {
                    salida.writeUTF("Acceso concedido. ¡Bienvenido!");
                } else {
                    salida.writeUTF("Acceso denegado");
                }

                entrada.close();
                salida.close();
                socketCliente.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        private boolean autenticarUsuario(String usuario, String contrasena) {
            String contrasenaCorrrecta = usuarios.get(usuario);
            return contrasenaCorrrecta != null && contrasenaCorrrecta.equals(contrasena);
        }
    }
    
}

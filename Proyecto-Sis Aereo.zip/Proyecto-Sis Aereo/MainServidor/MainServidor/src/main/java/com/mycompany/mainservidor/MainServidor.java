/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.mainservidor;

/**
 *
 * @author camim
 */
public class MainServidor {

    public static void main(String[] args) {
        Servidor.iniciarServidor();
    }
}

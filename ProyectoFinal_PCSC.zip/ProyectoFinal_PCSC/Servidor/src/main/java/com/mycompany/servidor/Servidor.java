/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.servidor;

/**
 *
 * @author User
 */
public class Servidor {

    public static void main(String[] args) {
        ServidorSocket.iniciarServidor();
    }
}

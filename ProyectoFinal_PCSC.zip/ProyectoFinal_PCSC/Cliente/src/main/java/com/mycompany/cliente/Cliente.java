/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.cliente;

/**
 *
 * @author User
 */
public class Cliente {
    public static void main(String[] args) {
        ClienteSocket.iniciarConexion();
    }
}
